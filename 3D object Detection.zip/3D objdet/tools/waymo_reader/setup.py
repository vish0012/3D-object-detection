from setuptools import setup

setup(
        name="simple_waymo_open_dataset_reader",
        packages=['simple_waymo_open_dataset_reader'],
        install_requires=['protobuf'])

